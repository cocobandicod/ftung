<?php
session_start();
require_once('../../../config/cek_ajax.php');
?>
<div class="modal-body text-center">
    <img src="<?= $_POST['link']; ?>" class="img-fluid rounded">
</div>